# Notebook Run Results — Customer Sentiment Analysis (Jio Digital)

> ⚠️ These results are from the **synthetic placeholder dataset** the notebook auto-generated
> (only ~240 unique cleaned reviews from a handful of templates), since this run happened
> before the real `Dataset-SA.csv` (205K rows) was located. Re-run the notebook with the real
> CSV in place to get realistic, non-trivial metrics — the perfect 1.00 scores below are an
> artifact of the synthetic data's repetitive templates, not real-world performance.

## Model Comparison Table

| Model | Accuracy | Precision | Recall | F1-Score |
|---|---|---|---|---|
| Logistic Regression | 1.000 | 1.000 | 1.000 | 1.000 |
| Multinomial NB | 1.000 | 1.000 | 1.000 | 1.000 |
| Linear SVM | 1.000 | 1.000 | 1.000 | 1.000 |
| Decision Tree | 1.000 | 1.000 | 1.000 | 1.000 |
| Random Forest | 1.000 | 1.000 | 1.000 | 1.000 |
| KNN | 1.000 | 1.000 | 1.000 | 1.000 |
| Gradient Boosting | 1.000 | 1.000 | 1.000 | 1.000 |
| XGBoost | 1.000 | 1.000 | 1.000 | 1.000 |

**Best model selected:** Logistic Regression (first by F1 tie-break)
Test set size was only 48 samples (16 per class) — too small to be meaningful; this will look very different on the real 205K-row dataset.

## Image Index (17 plots extracted from notebook outputs)
1. `01_class_distribution.png` — class balance bar chart
2. `02_missing_value_heatmap.png` — post-cleaning missing-value heatmap
3. `03_overall_wordcloud.png` — overall corpus wordcloud
4. `04_sentiment_wordclouds.png` — Positive / Negative / Neutral wordclouds side by side
5. `05_review_length_distribution.png` — character-length histogram
6. `06_top20_common_words.png` — most frequent unigrams
7. `07_top15_bigrams.png` — most frequent bigrams
8. `08_top15_trigrams.png` — most frequent trigrams
9–16. `09…16_confusion_matrix_<Model>.png` — confusion matrix per model (Logistic Regression, Multinomial NB, Linear SVM, Decision Tree, Random Forest, KNN, Gradient Boosting, XGBoost)
17. `17_feature_importance_top20.png` — top 20 |coefficient| features for the tuned best model (Logistic Regression)

## Sample Prediction Function Output (5 test reviews)
| Review (truncated) | Predicted | P(Positive) | P(Negative) | P(Neutral) |
|---|---|---|---|---|
| "JioFiber connection has been amazing, super fast..." | Positive | 0.373 | 0.320 | 0.307 |
| "Worst customer service, my complaint pending..." | Negative | 0.305 | 0.372 | 0.323 |
| "The app is okay, does what it needs to..." | Neutral | 0.320 | 0.313 | 0.367 |
| "Network keeps dropping calls constantly..." | Negative | 0.309 | 0.397 | 0.294 |
| "Great recharge offers and the new UI update..." | Positive | 0.401 | 0.308 | 0.292 |

All 5 sample predictions matched the expected sentiment correctly. Probabilities are close to uniform (~0.3 each) because the underlying training vocabulary was small — this will sharpen up substantially once trained on the real Kaggle dataset.
